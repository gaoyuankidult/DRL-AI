#ifndef COMMON_H
#define COMMON_H

#include <vector>
#include <string>
#include <cuda.h>
#include <cublas_v2.h>
#include <cuda_runtime.h>
#include <curand.h>

typedef std::vector<std::string> FileNames;
typedef unsigned char uInt8;

#define CUDA_KERNEL_LOOP(i, n) \
   for (int i = blockIdx.x * blockDim.x + threadIdx.x; \
        i < (n); \
        i += blockDim.x * gridDim.x)


#endif
