#ifndef LAYER_H
#define LAYER_H
#include <vector>
#include <string>

#include "parameter.h"
#include "common.h"
#include "nn.h"

class Layer {
 public:
  Layer(NNParameter* nn_para, LayerParameter* layer_para) {
    nn_para_ = nn_para;
  };

  ~Layer() {};

  void Im2Col(float* im, int im_size, int filter_size, int stride, float* im_col);
  void Col2Im(float* im_col, int im_size, int filter_size, int stride, float* im);
  void Conv2(float *im, float *Wc, int im_size, int filter_size, int filter_num, float alpha, float *output);
  void Rect(float *x, int size);
  void RectDiff(float *output, float *delta, int size);
  void Constants(float *x, int size, float value);
  void RandUniform(float *x, int size, float value);
  void RandGauss(float *x, int size, float value); 

  virtual void Init(Layer* top, Layer* bottom, curandGenerator_t gen, cublasHandle_t handle) {};  
  virtual void Forward() {};
  virtual void Backward() {};
  virtual void GetGradient() {} ;
  virtual void Update() {};
  virtual void WriteWeights(std::ofstream& file_out) {};
  virtual void ReadWeights(std::ifstream& file_in) {};
  
  std::string type_;

  int input_im_size_;
  int input_size_;
  int input_num_;  
  int output_im_size_;
  int output_size_;
  int output_num_;  

  int action_;
  int reward_;

  NNParameter* nn_para_;

  float* input_;
  float* output_;
  float* delta_;
  Layer* top_;
  Layer* bottom_;
  
  
  curandGenerator_t gen_;
  cublasHandle_t handle_; 
  
  
};


Layer* GetLayer(NNParameter* nn_para, LayerParameter *layer_para);

class ConvLayer : public Layer {  
 public: 
  ConvLayer(NNParameter* nn_para, LayerParameter *layer_para) : Layer(nn_para, layer_para) {
    type_ = "conv";    
    filter_num_ = layer_para->filter_num_;
    filter_size_ = layer_para->filter_size_;  
    stride_ = layer_para->stride_;    
    output_num_ = filter_num_;    
  };

  ~ConvLayer() {    
    delete[] output_;
    delete[] delta_;
    delete[] weight_;
    delete[] bias_;
    delete[] grad_weight_;
    delete[] grad_bias_;
  };  

  void Init(Layer* bottom, Layer* top, curandGenerator_t gen, cublasHandle_t handle);
  void Forward();
  void Backward();
  void GetGradient();
  void Update();
  void WriteWeights(std::ofstream& file_out);
  void ReadWeights(std::ifstream& file_in);
  
  int filter_num_;
  int filter_size_;      
  int stride_;
  float* weight_;
  float* bias_;  
  float* grad_weight_;
  float* grad_bias_;
  float* im_col_;
  float* im_col_getgradient_;
  float* ones_;
};

class FullRectLayer : public Layer {  
 public:   
  FullRectLayer(NNParameter* nn_para, LayerParameter *layer_para) : Layer(nn_para, layer_para) {    
    type_ = "full_rect";
    output_im_size_ = 0;
    output_size_ = layer_para->output_size_;
    output_num_ = 1;
  };

  ~FullRectLayer() {
    delete[] output_;
    delete[] delta_;    
    delete[] weight_;
    delete[] bias_;  
    delete[] grad_weight_;
    delete[] grad_bias_;
  };      

  void Init(Layer* bottom, Layer* top, curandGenerator_t gen, cublasHandle_t handle);
  void Forward();
  void Backward();
  void GetGradient();
  void Update();
  void WriteWeights(std::ofstream& file_out);
  void ReadWeights(std::ifstream& file_in);
  
  float* weight_;
  float* bias_;  
  float* grad_weight_;
  float* grad_bias_;
};

class FullLinearLayer : public Layer {  
 public:   
  FullLinearLayer(NNParameter* nn_para, LayerParameter *layer_para) : Layer(nn_para, layer_para) {    
    type_ = "full_linear";
    output_im_size_ = 0;
    output_size_ = layer_para->output_size_;
    output_num_ = 1;
  };

  ~FullLinearLayer() {
    delete[] output_;
    delete[] delta_;    
    delete[] weight_;
    delete[] bias_;  
    delete[] grad_weight_;
    delete[] grad_bias_;
  };      

  void Init(Layer* bottom, Layer* top, curandGenerator_t gen, cublasHandle_t handle);
  void Forward();
  void Backward();
  void GetGradient();
  void Update();
  void WriteWeights(std::ofstream& file_out);
  void ReadWeights(std::ifstream& file_in);
  
  
  float* weight_;
  float* bias_;  
  float* grad_weight_;
  float* grad_bias_;
};

#endif
