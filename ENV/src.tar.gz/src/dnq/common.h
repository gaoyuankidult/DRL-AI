#ifndef COMMON_H
#define COMMON_H

#include <vector>
#include <string>

typedef std::vector<std::string> FileNames;
typedef unsigned char uInt8;

#endif